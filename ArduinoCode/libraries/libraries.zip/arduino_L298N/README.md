ARDUINO L298N
=============

L298N Dual H-Bridge library for controlling via PWN 2 motors

SCHEMATICS
==========
designed using <a href="http://fritzing.org/home/">fritzing </a>
![alt tag](http://oi62.tinypic.com/314pj6v.jpg)

I take the L298N Fritzing part from this repo https://github.com/ComputacaoNaEscola/Fritzing
and modify it, adding the 4 extra pings for ENA,ENB and 2 5V+ pings for ENA and ENB pins

![alt tag](http://oi62.tinypic.com/302cubn.jpg)
